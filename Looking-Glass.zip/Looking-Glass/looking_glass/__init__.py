"""Looking Glass local editor."""
